/**
 * Newsletter subscription handler
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get the newsletter form element
    const newsletterForm = document.getElementById('newsletterForm');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Get email value
            const email = document.getElementById('newsletter-email').value;
            
            // Basic validation
            if (!email) {
                showSubscribeMessage('Please enter your email address', 'danger');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showSubscribeMessage('Please enter a valid email address', 'danger');
                return;
            }
            
            try {
                // Show loading state
                const submitButton = newsletterForm.querySelector('button[type="submit"]');
                const originalButtonText = submitButton.innerHTML;
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Subscribing...';
                
                // Send data to the server
                const response = await fetch('/api/subscribe', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        email
                    })
                });
                
                const data = await response.json();
                
                // Reset button state
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
                
                if (response.ok) {
                    // Show success message
                    showSubscribeMessage(data.message, 'success');
                    // Reset form
                    newsletterForm.reset();
                } else {
                    // Show error message
                    showSubscribeMessage(data.message || 'Something went wrong. Please try again.', 'danger');
                }
            } catch (error) {
                console.error('Error:', error);
                showSubscribeMessage('An error occurred. Please try again later.', 'danger');
                
                // Reset button state
                const submitButton = newsletterForm.querySelector('button[type="submit"]');
                submitButton.disabled = false;
                submitButton.innerHTML = 'Subscribe';
            }
        });
    }
    
    // Function to show subscription messages
    function showSubscribeMessage(message, type) {
        const messageElement = document.getElementById('newsletter-status');
        if (messageElement) {
            messageElement.className = `newsletter-message alert alert-${type} d-block mt-2`;
            messageElement.textContent = message;
            
            // Automatically hide the message after 5 seconds
            setTimeout(() => {
                messageElement.className = 'newsletter-message d-none';
            }, 5000);
        }
    }
});