// Main JavaScript for DigitalCraft Studio website

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the active navigation based on scroll position
    updateActiveNav();
    
    // Add animation classes to elements when they come into view
    animateOnScroll();
    
    // Handle contact form submission
    setupContactForm();
    
    // Initialize scroll event listeners
    window.addEventListener('scroll', function() {
        updateActiveNav();
        animateOnScroll();
    });

    // Initialize resize event listeners
    window.addEventListener('resize', function() {
        updateActiveNav();
    });
});

/**
 * Updates the active navigation link based on scroll position
 */
function updateActiveNav() {
    // Get all sections that have an ID defined
    const sections = document.querySelectorAll("section[id], header[id]");
    
    // Get current scroll position
    let scrollY = window.pageYOffset;
    
    // Loop through sections to get height, top and ID values for each
    sections.forEach(current => {
        const sectionHeight = current.offsetHeight;
        const sectionTop = current.offsetTop - 100; // Adjust offset for fixed navbar
        const sectionId = current.getAttribute("id");
        
        // If our current scroll position enters the space where current section is
        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            // Remove active class from all navigation links
            document.querySelectorAll('.navbar-nav a.nav-link').forEach(navLink => {
                navLink.classList.remove("active");
            });
            
            // Add active class to corresponding navigation link
            const correspondingNavLink = document.querySelector(`.navbar-nav a[href="#${sectionId}"]`);
            if (correspondingNavLink) {
                correspondingNavLink.classList.add("active");
            }
        }
    });
}

/**
 * Adds animation classes to elements when they come into view
 */
function animateOnScroll() {
    const elementsToAnimate = document.querySelectorAll('.service-card, .portfolio-item, .testimonial-card, .contact-card, .contact-info');
    
    elementsToAnimate.forEach(element => {
        // Check if element is in viewport
        const elementPosition = element.getBoundingClientRect();
        const windowHeight = window.innerHeight;
        
        if (elementPosition.top < windowHeight * 0.9) {
            element.classList.add('fade-in');
        }
    });
    
    // Add slide-up animation to section headings
    const headingsToAnimate = document.querySelectorAll('.section-heading, h3');
    
    headingsToAnimate.forEach(heading => {
        const headingPosition = heading.getBoundingClientRect();
        const windowHeight = window.innerHeight;
        
        if (headingPosition.top < windowHeight * 0.9) {
            heading.classList.add('slide-up');
        }
    });
}

/**
 * Sets up contact form validation and submission
 */
function setupContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            
            // Basic validation
            if (!name || !email || !subject || !message) {
                alert('Please fill in all fields');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address');
                return;
            }
            
            // Show success message (in a real application, this would send the form data to a server)
            alert('Thank you! Your message has been sent successfully. We will get back to you soon.');
            contactForm.reset();
        });
    }
}

/**
 * Adds parallax effect to hero section
 */
window.addEventListener('scroll', function() {
    const scrollPosition = window.pageYOffset;
    
    // Apply parallax effect to hero section
    if (scrollPosition < window.innerHeight) {
        const heroSection = document.querySelector('.hero-section');
        if (heroSection) {
            heroSection.style.backgroundPosition = `center ${scrollPosition * 0.5}px`;
        }
    }
});
