/**
 * Animated Scroll-to-Top Button with Rocket Effect
 * Creates a playful rocket animation when returning to the top of the page
 */

document.addEventListener('DOMContentLoaded', function() {
    // Create the scroll-to-top button element
    const scrollToTopBtn = document.createElement('div');
    scrollToTopBtn.className = 'scroll-to-top';
    scrollToTopBtn.innerHTML = '<i class="fas fa-rocket"></i><div class="rocket-flame"></div>';
    document.body.appendChild(scrollToTopBtn);
    
    // Show/hide button based on scroll position
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollToTopBtn.classList.add('visible');
        } else {
            scrollToTopBtn.classList.remove('visible');
            scrollToTopBtn.classList.remove('launching');
        }
    });
    
    // Handle click event for scrolling to top
    scrollToTopBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Add launching animation
        this.classList.add('launching');
        
        // Wait for animation to complete then scroll to top
        setTimeout(() => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            
            // Reset rocket after scrolling
            setTimeout(() => {
                this.classList.remove('launching');
            }, 1000);
        }, 300);
    });
    
    // Automatisches Scrollen wurde auf Wunsch entfernt
});