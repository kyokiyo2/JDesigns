/**
 * Interactive button effects
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get all buttons on the page
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        // Add 3D tilt effect on mousemove
        button.addEventListener('mousemove', function(e) {
            const btnRect = this.getBoundingClientRect();
            const x = e.clientX - btnRect.left;
            const y = e.clientY - btnRect.top;
            
            // Calculate rotation based on mouse position
            const xRotation = (y / btnRect.height - 0.5) * 10; // -5 to 5 degrees
            const yRotation = (0.5 - x / btnRect.width) * 10; // -5 to 5 degrees
            
            // Apply the rotation transform
            this.style.transform = `perspective(1000px) rotateX(${xRotation}deg) rotateY(${yRotation}deg) scale(1.05)`;
        });
        
        // Reset transform on mouseout
        button.addEventListener('mouseout', function() {
            this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
        });
        
        // Add click effect
        button.addEventListener('click', function() {
            // Add a temporary class for animation
            this.classList.add('btn-pulse');
            
            // Remove the class after animation completes
            setTimeout(() => {
                this.classList.remove('btn-pulse');
            }, 500);
        });
    });
});