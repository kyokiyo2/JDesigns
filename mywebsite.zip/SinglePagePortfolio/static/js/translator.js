/**
 * Website translator functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Check if language dropdown exists already - don't add it if it's already there
    const existingDropdown = document.querySelector('#languageDropdown');
    if (!existingDropdown) {
        // Add language selector to the navbar only if it doesn't exist
        const navbarNav = document.querySelector('.navbar-nav');
        if (navbarNav) {
            const languageSelector = document.createElement('li');
            languageSelector.className = 'nav-item dropdown';
            languageSelector.innerHTML = `
                <a class="nav-link dropdown-toggle" href="#" id="languageDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-globe me-1"></i> Language
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                    <li><a class="dropdown-item active" href="#" data-language="en">English</a></li>
                    <li><a class="dropdown-item" href="#" data-language="de">Deutsch</a></li>
                </ul>
            `;
            navbarNav.appendChild(languageSelector);
        }
        
        // Setup language switcher
        const languageItems = document.querySelectorAll('[data-language]');
        languageItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const language = this.getAttribute('data-language');
                
                // Update active class
                languageItems.forEach(langItem => {
                    langItem.classList.remove('active');
                });
                this.classList.add('active');
                
                // Switch language
                translatePage(language);
                
                // Store language preference
                localStorage.setItem('preferredLanguage', language);
            });
        });
        
        // Check for stored language preference
        const storedLanguage = localStorage.getItem('preferredLanguage');
        if (storedLanguage) {
            const langItem = document.querySelector(`[data-language="${storedLanguage}"]`);
            if (langItem) {
                langItem.click();
            }
        }
    }
    
    /**
     * Function to translate the page content
     */
    function translatePage(language) {
        if (language === 'en') {
            // Restore English content
            const translatedElements = document.querySelectorAll('[data-original-text]');
            translatedElements.forEach(element => {
                element.textContent = element.getAttribute('data-original-text');
                element.removeAttribute('data-original-text');
            });
            return;
        }
        
        // Elements to translate
        const translatableElements = document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, a.nav-link, a.btn, label, button, .card-title, .card-text, .section-heading');
        
        translatableElements.forEach(element => {
            // Skip if already translated
            if (element.hasAttribute('data-original-text')) {
                return;
            }
            
            // Store original text
            const originalText = element.textContent.trim();
            if (originalText) {
                element.setAttribute('data-original-text', originalText);
                
                // Translate based on language
                if (language === 'de') {
                    element.textContent = translateToGerman(originalText);
                }
            }
        });
    }
    
    /**
     * Function to translate text to German
     * This is a simple mapping for demonstration purposes
     */
    function translateToGerman(text) {
        const translations = {
            // Navigation
            "Home": "Startseite",
            "Services": "Dienste",
            "Web Design": "Webdesign",
            "SEO": "SEO",
            "Contact": "Kontakt",
            "Reviews": "Bewertungen",
            "Language": "Sprache",
            
            // Hero Section
            "Elevate Your Digital Presence": "Verbessern Sie Ihre digitale Präsenz",
            "Web Design & Social Media Solutions": "Webdesign & Social Media Lösungen",
            "We create stunning websites and engaging social media content that drives results for your business.": "Wir erstellen beeindruckende Websites und ansprechende Social-Media-Inhalte, die Ergebnisse für Ihr Unternehmen liefern.",
            "Our Services": "Unsere Dienste",
            "Get in Touch": "Kontakt aufnehmen",
            
            // Services Section
            "Our Services": "Unsere Dienste",
            "We offer comprehensive digital solutions to boost your online presence": "Wir bieten umfassende digitale Lösungen zur Verbesserung Ihrer Online-Präsenz",
            "Web Design": "Webdesign",
            "Custom websites that capture your brand's essence and convert visitors into customers.": "Maßgeschneiderte Websites, die das Wesen Ihrer Marke einfangen und Besucher in Kunden verwandeln.",
            "Responsive layouts that work on all devices": "Responsive Layouts, die auf allen Geräten funktionieren",
            "SEO-friendly structure": "SEO-freundliche Struktur",
            "Modern, eye-catching designs": "Moderne, ansprechende Designs",
            "Fast loading and optimized performance": "Schnelles Laden und optimierte Leistung",
            "Starting at": "Ab",
            
            // Social Media
            "Social Media Ad Posting": "Social Media Anzeigendienst",
            "Social Media Ad Posting Service": "Social Media Anzeigendienst",
            "AI-powered social media advertising that drives engagement and results.": "KI-gesteuerte Social-Media-Werbung, die Engagement und Ergebnisse liefert.",
            "AI-generated ad content creation": "KI-generierte Anzeigeninhalte",
            "Strategic ad placement and scheduling": "Strategische Anzeigenplatzierung und -planung",
            "Performance analytics and reporting": "Leistungsanalyse und Berichterstattung",
            "Targeted audience growth strategies": "Gezielte Strategien zum Wachstum der Zielgruppe",
            "Monthly service": "Monatlicher Service",
            
            // SEO Section
            "SEO Services": "SEO-Dienste",
            "Search Engine Optimization": "Suchmaschinenoptimierung",
            "Boost your online visibility and drive organic traffic with our comprehensive SEO services.": "Steigern Sie Ihre Online-Sichtbarkeit und steigern Sie den organischen Traffic mit unseren umfassenden SEO-Diensten.",
            "Keyword Research": "Schlüsselwortrecherche",
            "We analyze vast datasets to identify relevant keywords and long-tail keywords, helping to target specific search queries that matter to your business.": "Wir analysieren umfangreiche Datensätze, um relevante Keywords und Long-Tail-Keywords zu identifizieren, die bei der Ausrichtung auf spezifische Suchanfragen helfen, die für Ihr Unternehmen wichtig sind.",
            "Data Analysis and Reporting": "Datenanalyse und Berichterstattung",
            "Our detailed analytics and reporting provide insights into your website's performance, helping you make data-driven decisions to improve your SEO strategy.": "Unsere detaillierten Analysen und Berichte bieten Einblicke in die Leistung Ihrer Website und helfen Ihnen, datengestützte Entscheidungen zur Verbesserung Ihrer SEO-Strategie zu treffen.",
            "Technical SEO": "Technisches SEO",
            "We analyze your website's structure and identify technical issues that may be hindering its performance, ensuring optimal crawlability and indexing by search engines.": "Wir analysieren die Struktur Ihrer Website und identifizieren technische Probleme, die ihre Leistung beeinträchtigen könnten, um optimale Crawlbarkeit und Indexierung durch Suchmaschinen zu gewährleisten.",
            "Voice Search Optimization": "Sprachsuchoptimierung",
            "We optimize content for voice search, helping your website rank higher in voice search results as this technology continues to grow in popularity.": "Wir optimieren Inhalte für die Sprachsuche und helfen Ihrer Website, in den Ergebnissen der Sprachsuche höher zu ranken, da diese Technologie immer beliebter wird.",
            
            // Templates Page
            "Website Templates": "Website-Vorlagen",
            "Premium templates for different industries and purposes": "Premium-Vorlagen für verschiedene Branchen und Zwecke",
            "All Templates": "Alle Vorlagen",
            "Business": "Geschäft",
            "Restaurant": "Restaurant",
            "Portfolio": "Portfolio",
            "E-Commerce": "E-Commerce",
            "Blog": "Blog",
            "Personal": "Persönlich",
            "Preview": "Vorschau",
            "Gourmet Bistro": "Gourmet Bistro",
            "Elegant and tasteful design for restaurants, cafes and food businesses. Includes menu sections, reservation system and chef profiles.": "Elegantes und geschmackvolles Design für Restaurants, Cafés und Lebensmittelgeschäfte. Umfasst Menüabschnitte, Reservierungssystem und Kochprofile.",
            "Menu presentation": "Menüpräsentation",
            "Reservation system": "Reservierungssystem",
            "Mobile responsive": "Mobilgerätekompatibel",
            "Creative Portfolio": "Kreatives Portfolio",
            "Showcase your work with this elegant portfolio template. Perfect for photographers, designers, and creative professionals.": "Präsentieren Sie Ihre Arbeit mit dieser eleganten Portfolio-Vorlage. Perfekt für Fotografen, Designer und Kreativprofis.",
            "Project gallery": "Projektgalerie",
            "Filterable portfolio": "Filterbares Portfolio",
            "Contact form": "Kontaktformular",
            "Corporate Pro": "Corporate Pro",
            "Professional business template with a clean and modern design. Ideal for companies, agencies, and corporate websites.": "Professionelle Geschäftsvorlage mit einem klaren und modernen Design. Ideal für Unternehmen, Agenturen und Unternehmenswebsites.",
            "Service showcases": "Service-Präsentationen",
            "Team section": "Team-Bereich",
            "Testimonials": "Testimonials",
            "Shop Elite": "Shop Elite",
            "Complete e-commerce solution with product listings, cart functionality, and checkout process. Start selling online today.": "Komplette E-Commerce-Lösung mit Produktlisten, Warenkorbfunktionalität und Checkout-Prozess. Beginnen Sie noch heute mit dem Online-Verkauf.",
            "Product catalog": "Produktkatalog",
            "Shopping cart": "Warenkorb",
            "Payment integration": "Zahlungsintegration",
            "Writer's Corner": "Writer's Corner",
            "Clean and minimalist blog template designed for writers, content creators, and online magazines. Focus on your content.": "Saubere und minimalistische Blog-Vorlage für Autoren, Content-Ersteller und Online-Magazine. Konzentrieren Sie sich auf Ihren Inhalt.",
            "Category organization": "Kategorieorganisation",
            "Comments section": "Kommentarbereich",
            "Newsletter integration": "Newsletter-Integration",
            "Personal Brand": "Personal Brand",
            "Showcase your personal brand with this professional template. Perfect for freelancers, consultants, and job seekers.": "Präsentieren Sie Ihre persönliche Marke mit dieser professionellen Vorlage. Perfekt für Freiberufler, Berater und Arbeitssuchende.",
            "Resume section": "Lebenslauf-Bereich",
            "Skills showcase": "Fähigkeiten-Präsentation",
            "Project portfolio": "Projektportfolio",
            "Need a Custom Website?": "Benötigen Sie eine maßgeschneiderte Website?",
            "Don't see a template that fits your needs? We can create a custom website tailored specifically to your business requirements.": "Sehen Sie keine Vorlage, die zu Ihren Bedürfnissen passt? Wir können eine maßgeschneiderte Website erstellen, die speziell auf Ihre Geschäftsanforderungen zugeschnitten ist.",
            "Get in Touch": "Kontakt aufnehmen",
            "Restaurant Template": "Restaurant-Vorlage",
            "Perfect for restaurants, cafes, and food businesses.": "Perfekt für Restaurants, Cafés und Lebensmittelgeschäfte.",
            "Portfolio Template": "Portfolio-Vorlage",
            "Showcase your work with this elegant design.": "Präsentieren Sie Ihre Arbeit mit diesem eleganten Design.",
            "E-Commerce Template": "E-Commerce-Vorlage",
            "Start selling your products online today.": "Beginnen Sie noch heute mit dem Online-Verkauf Ihrer Produkte.",
            "Comprehensive search engine optimization to improve your site's visibility.": "Umfassende Suchmaschinenoptimierung zur Verbesserung der Sichtbarkeit Ihrer Website.",
            "Monthly keyword performance analysis": "Monatliche Keyword-Leistungsanalyse",
            "Detailed traffic reporting": "Detaillierte Traffic-Berichte",
            "Competitor tracking": "Wettbewerber-Tracking",
            "Strategic SEO recommendations": "Strategische SEO-Empfehlungen",
            "Content optimization guidance": "Anleitung zur Content-Optimierung",
            
            // Mobile Responsive
            "Mobile Responsive": "Mobilgeräteoptimiert",
            "Did you know that over half of website traffic comes from mobiles? We design all our websites to work perfectly and look beautiful on phones as well as on other devices.": "Wussten Sie, dass über die Hälfte des Website-Verkehrs von Mobilgeräten stammt? Wir gestalten alle unsere Websites so, dass sie auf Telefonen sowie auf anderen Geräten perfekt funktionieren und gut aussehen.",
            
            // Package Sections
            "Additional Services & Packages": "Zusätzliche Dienste & Pakete",
            "Lifetime Website Package": "Lifetime Website-Paket",
            "All-inclusive permanent website hosting and maintenance package with premium features.": "All-inclusive permanentes Website-Hosting und Wartungspaket mit Premium-Funktionen.",
            "Permanent future hosting & maintenance": "Dauerhaftes zukünftiges Hosting & Wartung",
            "SEO (keywords) and traffic reports": "SEO (Keywords) und Traffic-Berichte",
            "Website changes & updates included": "Website-Änderungen & Updates inklusive",
            "Lifetime technical support": "Lebenslanger technischer Support",
            "Regular performance optimization": "Regelmäßige Leistungsoptimierung",
            "One-time fee": "Einmalige Gebühr",
            
            "Website Maintenance Subscription": "Website-Wartungsabonnement",
            "Keep your website running smoothly with our all-inclusive maintenance plan.": "Halten Sie Ihre Website mit unserem All-inclusive-Wartungsplan reibungslos am Laufen.",
            "Website hosting & server management": "Website-Hosting & Server-Management",
            "Regular maintenance & updates": "Regelmäßige Wartung & Updates",
            "Monthly traffic reports": "Monatliche Traffic-Berichte",
            "Content changes & minor website updates": "Inhaltsänderungen & kleinere Website-Updates",
            "Monthly subscription": "Monatliches Abonnement",
            
            // Payment Section
            "Secure Payment Options": "Sichere Zahlungsmöglichkeiten",
            "We offer various secure payment methods for your convenience": "Wir bieten verschiedene sichere Zahlungsmethoden für Ihre Bequemlichkeit",
            "Credit Card": "Kreditkarte",
            "Bank Transfer": "Banküberweisung",
            "PayPal": "PayPal",
            "All payments are processed through certified and secure platforms": "Alle Zahlungen werden über zertifizierte und sichere Plattformen abgewickelt",
            
            // Reviews Section
            "Kundenbewertungen": "Customer Reviews",
            "Was unsere Kunden über unsere Dienstleistungen sagen": "What our customers say about our services",
            "Ich kann J Designs nur weiterempfehlen, website ist wirklich toll geworden!": "I can only recommend J Designs, the website turned out really great!",
            
            // Contact Section
            "Get in Touch": "Kontakt aufnehmen",
            "Ready to elevate your digital presence? Let's talk about your project.": "Bereit, Ihre digitale Präsenz zu verbessern? Lassen Sie uns über Ihr Projekt sprechen.",
            "Contact Information": "Kontaktinformationen",
            "Connect With Us": "Verbinden Sie sich mit uns",
            "Send Us a Message": "Senden Sie uns eine Nachricht",
            "Your Name": "Ihr Name",
            "Your Email": "Ihre E-Mail",
            "Subject": "Betreff",
            "Your Message": "Ihre Nachricht",
            "I agree to the privacy policy": "Ich stimme der Datenschutzrichtlinie zu",
            "Send Message": "Nachricht senden",
            "Senden Sie uns Ihre Dateien (Bilder, Logos, Videos, etc.)": "Send us your files (images, logos, videos, etc.)",
            "Hochladen von Bildern, Logos, Videos und anderen Dateien für Ihr Website-Projekt.": "Upload images, logos, videos and other files for your website project.",
            "Nachricht senden": "Send Message",
            
            // Footer
            "All rights reserved.": "Alle Rechte vorbehalten.",
            "Back to Top": "Nach oben",
            
            // Web Design Page
            "Web Design Services": "Webdesign-Dienstleistungen",
            "Custom, responsive websites that capture your brand's essence and convert visitors into customers": "Maßgeschneiderte, responsive Websites, die das Wesen Ihrer Marke einfangen und Besucher in Kunden verwandeln",
            "Creating Websites That Work": "Websites erstellen, die funktionieren",
            "At J Designs, we build custom websites that not only look stunning but also drive real business results.": "Bei J Designs erstellen wir maßgeschneiderte Websites, die nicht nur atemberaubend aussehen, sondern auch echte Geschäftsergebnisse liefern.",
            "Whether you're starting from scratch or revamping an existing site, our web design services are tailored to meet your specific needs and goals. We focus on creating user-friendly experiences that engage your visitors and convert them into loyal customers.": "Egal, ob Sie von Grund auf neu beginnen oder eine bestehende Website überarbeiten, unsere Webdesign-Dienstleistungen sind auf Ihre spezifischen Bedürfnisse und Ziele zugeschnitten. Wir konzentrieren uns darauf, benutzerfreundliche Erlebnisse zu schaffen, die Ihre Besucher ansprechen und sie in treue Kunden verwandeln.",
            "Mobile Responsive": "Mobilgeräteoptimiert",
            "Optimized for all devices": "Optimiert für alle Geräte",
            "SEO Friendly": "SEO-freundlich",
            "Built to rank in search engines": "Für Suchmaschinen optimiert",
            "Fast Loading": "Schnelles Laden",
            "Optimized for speed": "Für Geschwindigkeit optimiert",
            "Web Design Package Includes:": "Webdesign-Paket beinhaltet:",
            "Custom, responsive design": "Maßgeschneidertes, responsives Design",
            "Content management system": "Content-Management-System",
            "SEO optimization": "SEO-Optimierung",
            "Contact forms": "Kontaktformulare",
            "Social media integration": "Social-Media-Integration",
            "Google Analytics setup": "Google Analytics-Einrichtung",
            "Basic SEO setup": "Grundlegende SEO-Einrichtung",
            "Security features": "Sicherheitsmerkmale",
            "Starting at": "Ab",
            "Get Started": "Jetzt starten",
            "View Details": "Details anzeigen",
            "View All Templates": "Alle Templates anzeigen",
            "Our Web Design Process": "Unser Webdesign-Prozess",
            "We follow a strategic process to ensure your website succeeds": "Wir folgen einem strategischen Prozess, um den Erfolg Ihrer Website zu gewährleisten",
            "Discovery & Planning": "Entdeckung & Planung",
            "We start by understanding your business, goals, and target audience to create a strategic plan.": "Wir beginnen damit, Ihr Unternehmen, Ihre Ziele und Ihre Zielgruppe zu verstehen, um einen strategischen Plan zu erstellen.",
            "Design & Wireframing": "Design & Wireframing",
            "Next, we create wireframes and visual designs that align with your brand and target audience.": "Als nächstes erstellen wir Wireframes und visuelle Designs, die auf Ihre Marke und Zielgruppe abgestimmt sind.",
            "Development & Content": "Entwicklung & Inhalt",
            "Our developers build your site while we work together on creating compelling content.": "Unsere Entwickler bauen Ihre Website, während wir gemeinsam an der Erstellung überzeugender Inhalte arbeiten.",
            "Testing & Launch": "Testen & Start",
            "We thoroughly test your website across devices before launching it to the world.": "Wir testen Ihre Website gründlich auf verschiedenen Geräten, bevor wir sie der Welt präsentieren.",
            "Technologies We Use": "Technologien, die wir verwenden",
            "HTML5": "HTML5",
            "CSS3": "CSS3",
            "JavaScript": "JavaScript",
            "WordPress": "WordPress",
            "React": "React",
            "Bootstrap": "Bootstrap",
            "MySQL": "MySQL",
            "Node.js": "Node.js",
            "API Integration": "API-Integration",
            "Modern web technologies for optimal performance": "Moderne Webtechnologien für optimale Leistung",
            "Why Choose Our Web Design Services?": "Warum unsere Webdesign-Dienstleistungen wählen?",
            "Benefits that set our services apart": "Vorteile, die unsere Dienstleistungen auszeichnen",
            "Custom Designs": "Maßgeschneiderte Designs",
            "No templates or cookie-cutter designs. Every website we create is uniquely designed for your specific brand and business needs.": "Keine Vorlagen oder Standarddesigns. Jede Website, die wir erstellen, wird individuell für Ihre spezifische Marke und Geschäftsanforderungen gestaltet.",
            "User-Focused": "Benutzerfokussiert",
            "We prioritize user experience to ensure visitors can easily navigate your site and find what they're looking for.": "Wir priorisieren die Benutzererfahrung, um sicherzustellen, dass Besucher Ihre Website leicht navigieren und finden können, wonach sie suchen.",
            "SEO Built-In": "Integriertes SEO",
            "Every site we build is optimized for search engines from the ground up, helping you rank better and get found online.": "Jede Website, die wir erstellen, ist von Grund auf für Suchmaschinen optimiert und hilft Ihnen, besser zu ranken und online gefunden zu werden.",
            "Mobile Optimized": "Für Mobilgeräte optimiert",
            "All our websites are fully responsive, ensuring they look and function perfectly on all devices and screen sizes.": "Alle unsere Websites sind vollständig responsiv und sehen auf allen Geräten und Bildschirmgrößen perfekt aus und funktionieren einwandfrei.",
            "Fast Performance": "Schnelle Leistung",
            "We optimize every aspect of your website for speed, ensuring quick load times that keep visitors engaged.": "Wir optimieren jeden Aspekt Ihrer Website für Geschwindigkeit und sorgen für schnelle Ladezeiten, die Besucher engagiert halten.",
            "Security Focused": "Sicherheitsfokussiert",
            "We implement robust security measures to protect your website and your customers' data from threats.": "Wir implementieren robuste Sicherheitsmaßnahmen, um Ihre Website und die Daten Ihrer Kunden vor Bedrohungen zu schützen.",
            "Ready to Transform Your Online Presence?": "Bereit, Ihre Online-Präsenz zu transformieren?",
            "Let's build a website that perfectly represents your brand and drives real business results.": "Lassen Sie uns eine Website erstellen, die Ihre Marke perfekt repräsentiert und echte Geschäftsergebnisse liefert.",
            "Get Your Free Consultation": "Holen Sie sich Ihre kostenlose Beratung",
            
            // Other common phrases
            "Language": "Sprache",
            "Thank you!": "Vielen Dank!",
            "Please fill in all fields": "Bitte füllen Sie alle Felder aus",
            "Please enter a valid email address": "Bitte geben Sie eine gültige E-Mail-Adresse ein"
        };
        
        // Check if there's a direct translation
        if (translations[text]) {
            return translations[text];
        }
        
        // Check for partial matches
        for (const [key, value] of Object.entries(translations)) {
            if (text.includes(key)) {
                return text.replace(key, value);
            }
        }
        
        // Return original text if no translation is found
        return text;
    }
});