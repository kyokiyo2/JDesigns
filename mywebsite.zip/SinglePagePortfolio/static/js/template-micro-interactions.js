/**
 * Template Micro-Interactions
 * 
 * Enhances template cards with subtle and delightful micro-interactions
 * to improve user engagement and provide visual feedback.
 */

document.addEventListener('DOMContentLoaded', function() {
    initTemplateMicroInteractions();
});

/**
 * Initialize all micro-interactions for template cards
 */
function initTemplateMicroInteractions() {
    // Select all template cards
    const templateCards = document.querySelectorAll('.template-card');
    
    templateCards.forEach(card => {
        // Add mouse movement effect (parallax)
        card.addEventListener('mousemove', handleMouseMove);
        
        // Add mouse enter effect
        card.addEventListener('mouseenter', handleMouseEnter);
        
        // Add mouse leave effect
        card.addEventListener('mouseleave', handleMouseLeave);
        
        // Add click effect
        card.addEventListener('click', handleCardClick);
        
        // Setup button hover animations
        setupButtonAnimations(card);
    });
}

/**
 * Handle mouse movement over template cards for parallax effect
 * @param {MouseEvent} e - The mouse event
 */
function handleMouseMove(e) {
    const card = e.currentTarget;
    
    // Get the dimensions of the card
    const rect = card.getBoundingClientRect();
    
    // Calculate the mouse position relative to the card center
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    
    // Calculate rotation angle (capped at 5 degrees in each direction)
    const rotateX = Math.min(Math.max(-5, y / 10), 5);
    const rotateY = Math.min(Math.max(-5, -x / 10), 5);
    
    // Apply the transformation
    card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
    
    // Add shadow effect based on mouse position
    const shadowX = x / 25;
    const shadowY = y / 25;
    card.style.boxShadow = `${shadowX}px ${shadowY}px 30px rgba(0, 0, 0, 0.4)`;
    
    // Subtle movement of the image based on mouse position
    const image = card.querySelector('.template-image img');
    if (image) {
        image.style.transform = `translateX(${x / 50}px) translateY(${y / 50}px) scale(1.05)`;
    }
}

/**
 * Handle mouse enter on template cards
 * @param {MouseEvent} e - The mouse event
 */
function handleMouseEnter(e) {
    const card = e.currentTarget;
    
    // Add special class for active state
    card.classList.add('card-hover-active');
    
    // Create ripple effect
    createRippleEffect(card);
    
    // Animate feature items sequentially
    animateFeatureItems(card);
}

/**
 * Handle mouse leave on template cards
 * @param {MouseEvent} e - The mouse event
 */
function handleMouseLeave(e) {
    const card = e.currentTarget;
    
    // Remove hover class
    card.classList.remove('card-hover-active');
    
    // Reset transformations smoothly
    card.style.transform = '';
    card.style.boxShadow = '';
    
    // Reset image position
    const image = card.querySelector('.template-image img');
    if (image) {
        image.style.transform = '';
    }
}

/**
 * Handle click on template cards
 * @param {MouseEvent} e - The mouse event
 */
function handleCardClick(e) {
    // Only proceed if we're not clicking on a button or link
    if (e.target.tagName !== 'A' && e.target.tagName !== 'BUTTON' && !e.target.closest('a') && !e.target.closest('button')) {
        const card = e.currentTarget;
        
        // Add pulse effect
        card.classList.add('pulse-effect');
        
        // Remove pulse class after animation completes
        setTimeout(() => {
            card.classList.remove('pulse-effect');
        }, 500);
    }
}

/**
 * Create ripple effect when card is hovered
 * @param {HTMLElement} card - The template card element
 */
function createRippleEffect(card) {
    // Create ripple element if it doesn't exist
    if (!card.querySelector('.card-ripple')) {
        const ripple = document.createElement('div');
        ripple.className = 'card-ripple';
        card.appendChild(ripple);
        
        // Trigger animation
        setTimeout(() => {
            ripple.classList.add('animate');
        }, 10);
        
        // Remove ripple element after animation
        setTimeout(() => {
            ripple.remove();
        }, 1000);
    }
}

/**
 * Animate feature items sequentially
 * @param {HTMLElement} card - The template card element
 */
function animateFeatureItems(card) {
    const features = card.querySelectorAll('.template-features li');
    
    features.forEach((feature, index) => {
        // Reset any previous animations
        feature.style.transition = 'none';
        feature.style.opacity = '0';
        feature.style.transform = 'translateY(10px)';
        
        // Trigger animations with a delay between each item
        setTimeout(() => {
            feature.style.transition = 'all 0.3s ease';
            feature.style.opacity = '1';
            feature.style.transform = 'translateY(0)';
        }, 50 + (index * 50));
    });
}

/**
 * Setup button animations within card
 * @param {HTMLElement} card - The template card element
 */
function setupButtonAnimations(card) {
    const buttons = card.querySelectorAll('.btn');
    
    buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            button.classList.add('btn-pulse');
        });
        
        button.addEventListener('mouseleave', () => {
            button.classList.remove('btn-pulse');
        });
        
        button.addEventListener('click', (e) => {
            // Don't propagate click to the card
            e.stopPropagation();
            
            // Create circle pulse on button
            const circle = document.createElement('div');
            circle.className = 'btn-click-effect';
            button.appendChild(circle);
            
            // Remove the circle after animation completes
            setTimeout(() => {
                circle.remove();
            }, 500);
        });
    });
}