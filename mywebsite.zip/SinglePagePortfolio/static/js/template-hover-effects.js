/**
 * Enhanced Template Card Interactions
 * Adds playful and interactive hover effects to the website template cards
 */

document.addEventListener('DOMContentLoaded', function() {
    // Select all template cards
    const templateCards = document.querySelectorAll('.template-showcase-card');
    
    // Add event listeners to each card
    templateCards.forEach(card => {
        // Add 3D tilt effect on mouse move
        card.addEventListener('mousemove', handleMouseMove);
        
        // Reset card on mouse leave
        card.addEventListener('mouseleave', resetCard);
        
        // Add click effect
        card.addEventListener('mousedown', addClickEffect);
        card.addEventListener('mouseup', removeClickEffect);
        
        // Create highlight effect element
        const highlight = document.createElement('div');
        highlight.classList.add('card-highlight');
        card.appendChild(highlight);
    });
    
    // Handle mouse movement over card
    function handleMouseMove(e) {
        const card = e.currentTarget;
        const cardRect = card.getBoundingClientRect();
        
        // Calculate mouse position relative to card
        const x = e.clientX - cardRect.left;
        const y = e.clientY - cardRect.top;
        
        // Calculate rotation based on mouse position
        const centerX = cardRect.width / 2;
        const centerY = cardRect.height / 2;
        
        const rotateY = ((x - centerX) / centerX) * 5; // Max 5 degrees rotation
        const rotateX = ((centerY - y) / centerY) * 5; // Max 5 degrees rotation
        
        // Apply rotation and 3D effect
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-10px) scale(1.02)`;
        
        // Move highlight effect
        const highlight = card.querySelector('.card-highlight');
        highlight.style.opacity = '1';
        highlight.style.transform = `translate(${x}px, ${y}px)`;
    }
    
    // Reset card to original state
    function resetCard(e) {
        const card = e.currentTarget;
        card.style.transform = '';
        
        // Hide highlight
        const highlight = card.querySelector('.card-highlight');
        highlight.style.opacity = '0';
    }
    
    // Add click effect
    function addClickEffect(e) {
        const card = e.currentTarget;
        card.style.transform = `perspective(1000px) scale(0.98)`;
    }
    
    // Remove click effect
    function removeClickEffect(e) {
        const card = e.currentTarget;
        
        // Get mouse position to keep tilt effect
        const cardRect = card.getBoundingClientRect();
        const x = e.clientX - cardRect.left;
        const y = e.clientY - cardRect.top;
        const centerX = cardRect.width / 2;
        const centerY = cardRect.height / 2;
        const rotateY = ((x - centerX) / centerX) * 5;
        const rotateX = ((centerY - y) / centerY) * 5;
        
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-10px) scale(1.02)`;
    }
    
    // Add animation to "View Details" buttons
    const viewButtons = document.querySelectorAll('.template-showcase-card .btn');
    viewButtons.forEach(button => {
        button.addEventListener('mouseover', function() {
            this.textContent = "See Preview →";
        });
        
        button.addEventListener('mouseout', function() {
            this.textContent = "View Details";
        });
    });
});