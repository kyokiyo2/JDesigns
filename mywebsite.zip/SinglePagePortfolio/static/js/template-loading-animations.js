/**
 * Template Loading Animations
 * 
 * JavaScript functionality for the playful loading animations 
 * when transitioning between template previews
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the loading animations
    initTemplateLoadingAnimations();
});

/**
 * Initialize the template loading animations
 */
function initTemplateLoadingAnimations() {
    // Create the transition overlay if it doesn't exist
    if (!document.querySelector('.transition-overlay')) {
        createTransitionOverlay();
    }
    
    // Set up click handlers for all template preview links
    setupTemplatePreviewLinks();
}

/**
 * Create the transition overlay with the loading animations container
 */
function createTransitionOverlay() {
    // Create and append the overlay
    const overlay = document.createElement('div');
    overlay.classList.add('transition-overlay');
    document.body.appendChild(overlay);
    
    // Create container for the animations
    const container = document.createElement('div');
    container.classList.add('template-loading-container');
    overlay.appendChild(container);
    
    // Create default loader (will be replaced based on template type)
    const defaultLoader = createDefaultLoader();
    container.appendChild(defaultLoader);
    
    // Add loading message element
    const message = document.createElement('div');
    message.classList.add('template-loading-message');
    message.textContent = 'Loading preview...';
    container.appendChild(message);
}

/**
 * Create a default loader animation
 * @returns {HTMLElement} The default loader element
 */
function createDefaultLoader() {
    const loader = document.createElement('div');
    loader.classList.add('default-loader');
    
    const spinner = document.createElement('div');
    spinner.classList.add('spinner');
    loader.appendChild(spinner);
    
    const dot = document.createElement('div');
    dot.classList.add('dot');
    loader.appendChild(dot);
    
    return loader;
}

/**
 * Set up click handlers for all template preview links
 */
function setupTemplatePreviewLinks() {
    const previewLinks = document.querySelectorAll('.preview-btn');
    
    previewLinks.forEach(link => {
        link.addEventListener('click', handleTemplatePreviewClick);
    });
}

/**
 * Handle click on template preview links
 * @param {Event} e - The click event
 */
function handleTemplatePreviewClick(e) {
    e.preventDefault();
    const targetUrl = this.getAttribute('href');
    const templateType = this.getAttribute('data-template');
    
    // Show transition overlay with appropriate loader
    showTemplateLoader(templateType);
    
    // After a short delay, navigate to the template
    setTimeout(() => {
        window.location.href = targetUrl;
    }, 2000); // Show the animation for 2 seconds before navigating
}

/**
 * Show the template loader based on template type
 * @param {string} templateType - The type of template
 */
function showTemplateLoader(templateType) {
    const overlay = document.querySelector('.transition-overlay');
    const container = overlay.querySelector('.template-loading-container');
    
    // Clear any existing loaders
    container.innerHTML = '';
    
    // Create the appropriate loader based on template type
    let loader;
    let messages = [];
    
    if (templateType.includes('restaurant')) {
        loader = createRestaurantLoader();
        messages = [
            'Setting the tables...',
            'Preparing the menu...',
            'Polishing silverware...'
        ];
    } else if (templateType.includes('portfolio')) {
        loader = createPortfolioLoader();
        messages = [
            'Curating works...',
            'Framing projects...',
            'Arranging the gallery...'
        ];
    } else if (templateType.includes('ecommerce')) {
        loader = createEcommerceLoader();
        messages = [
            'Stocking shelves...',
            'Scanning barcodes...',
            'Preparing checkout...'
        ];
    } else if (templateType.includes('business')) {
        loader = createBusinessLoader();
        messages = [
            'Preparing presentation...',
            'Analyzing metrics...',
            'Organizing meeting...'
        ];
    } else if (templateType.includes('blog')) {
        loader = createBlogLoader();
        messages = [
            'Writing content...',
            'Selecting typography...',
            'Brewing inspiration...'
        ];
    } else if (templateType.includes('personal')) {
        loader = createPersonalLoader();
        messages = [
            'Polishing profile...',
            'Updating social links...',
            'Curating personal story...'
        ];
    } else {
        loader = createDefaultLoader();
        messages = [
            'Loading preview...',
            'Preparing template...',
            'Almost there...'
        ];
    }
    
    // Append the loader
    container.appendChild(loader);
    
    // Create and append loading message
    const messageElement = document.createElement('div');
    messageElement.classList.add('template-loading-message');
    messageElement.textContent = messages[0];
    container.appendChild(messageElement);
    
    // Cycle through messages
    let messageIndex = 1;
    const messageInterval = setInterval(() => {
        if (messageIndex >= messages.length) {
            messageIndex = 0;
        }
        messageElement.textContent = messages[messageIndex];
        messageIndex++;
    }, 2000);
    
    // Store the interval ID on the overlay to clear it later
    overlay.dataset.messageInterval = messageInterval;
    
    // Show the overlay
    overlay.classList.add('slide-in');
}

/**
 * Create restaurant template loader
 * @returns {HTMLElement} Restaurant loader
 */
function createRestaurantLoader() {
    const loader = document.createElement('div');
    loader.classList.add('restaurant-loader');
    
    const plate = document.createElement('div');
    plate.classList.add('plate');
    
    const fork = document.createElement('div');
    fork.classList.add('fork');
    
    const knife = document.createElement('div');
    knife.classList.add('knife');
    
    loader.appendChild(plate);
    loader.appendChild(fork);
    loader.appendChild(knife);
    
    return loader;
}

/**
 * Create portfolio template loader
 * @returns {HTMLElement} Portfolio loader
 */
function createPortfolioLoader() {
    const loader = document.createElement('div');
    loader.classList.add('portfolio-loader');
    
    const frame = document.createElement('div');
    frame.classList.add('frame');
    
    const picture = document.createElement('div');
    picture.classList.add('picture');
    
    const dot1 = document.createElement('div');
    dot1.classList.add('dot');
    
    const dot2 = document.createElement('div');
    dot2.classList.add('dot');
    
    const dot3 = document.createElement('div');
    dot3.classList.add('dot');
    
    loader.appendChild(frame);
    frame.appendChild(picture);
    loader.appendChild(dot1);
    loader.appendChild(dot2);
    loader.appendChild(dot3);
    
    return loader;
}

/**
 * Create e-commerce template loader
 * @returns {HTMLElement} E-commerce loader
 */
function createEcommerceLoader() {
    const loader = document.createElement('div');
    loader.classList.add('ecommerce-loader');
    
    const cart = document.createElement('div');
    cart.classList.add('cart');
    
    const handle = document.createElement('div');
    handle.classList.add('handle');
    
    const wheel1 = document.createElement('div');
    wheel1.classList.add('wheel');
    
    const wheel2 = document.createElement('div');
    wheel2.classList.add('wheel');
    
    const item1 = document.createElement('div');
    item1.classList.add('item');
    
    const item2 = document.createElement('div');
    item2.classList.add('item');
    
    const item3 = document.createElement('div');
    item3.classList.add('item');
    
    loader.appendChild(cart);
    cart.appendChild(handle);
    loader.appendChild(wheel1);
    loader.appendChild(wheel2);
    loader.appendChild(item1);
    loader.appendChild(item2);
    loader.appendChild(item3);
    
    return loader;
}

/**
 * Create business template loader
 * @returns {HTMLElement} Business loader
 */
function createBusinessLoader() {
    const loader = document.createElement('div');
    loader.classList.add('business-loader');
    
    const document = document.createElement('div');
    document.classList.add('document');
    
    const bar1 = document.createElement('div');
    bar1.classList.add('chart-bar');
    
    const bar2 = document.createElement('div');
    bar2.classList.add('chart-bar');
    
    const bar3 = document.createElement('div');
    bar3.classList.add('chart-bar');
    
    const line1 = document.createElement('div');
    line1.classList.add('line');
    
    const line2 = document.createElement('div');
    line2.classList.add('line');
    
    const line3 = document.createElement('div');
    line3.classList.add('line');
    
    loader.appendChild(document);
    document.appendChild(bar1);
    document.appendChild(bar2);
    document.appendChild(bar3);
    document.appendChild(line1);
    document.appendChild(line2);
    document.appendChild(line3);
    
    return loader;
}

/**
 * Create blog template loader
 * @returns {HTMLElement} Blog loader
 */
function createBlogLoader() {
    const loader = document.createElement('div');
    loader.classList.add('blog-loader');
    
    const paper = document.createElement('div');
    paper.classList.add('paper');
    
    const line1 = document.createElement('div');
    line1.classList.add('line');
    
    const line2 = document.createElement('div');
    line2.classList.add('line');
    
    const line3 = document.createElement('div');
    line3.classList.add('line');
    
    const line4 = document.createElement('div');
    line4.classList.add('line');
    
    const cursor = document.createElement('div');
    cursor.classList.add('cursor');
    
    loader.appendChild(paper);
    paper.appendChild(line1);
    paper.appendChild(line2);
    paper.appendChild(line3);
    paper.appendChild(line4);
    paper.appendChild(cursor);
    
    return loader;
}

/**
 * Create personal template loader
 * @returns {HTMLElement} Personal loader
 */
function createPersonalLoader() {
    const loader = document.createElement('div');
    loader.classList.add('personal-loader');
    
    const avatar = document.createElement('div');
    avatar.classList.add('avatar');
    
    const social1 = document.createElement('div');
    social1.classList.add('social');
    
    const social2 = document.createElement('div');
    social2.classList.add('social');
    
    const social3 = document.createElement('div');
    social3.classList.add('social');
    
    loader.appendChild(avatar);
    loader.appendChild(social1);
    loader.appendChild(social2);
    loader.appendChild(social3);
    
    return loader;
}

/**
 * Hide the template loader and clear any intervals
 */
function hideTemplateLoader() {
    const overlay = document.querySelector('.transition-overlay');
    if (overlay) {
        overlay.classList.remove('slide-in');
        
        // Clear any message cycling interval
        if (overlay.dataset.messageInterval) {
            clearInterval(parseInt(overlay.dataset.messageInterval));
        }
    }
}