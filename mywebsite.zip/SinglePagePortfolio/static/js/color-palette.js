/**
 * Color Palette Preview Tool
 * 
 * Ermöglicht dem Benutzer, die Farben der Templates anzupassen und in Echtzeit zu sehen,
 * wie sich verschiedene Farbschemata auf das Design auswirken.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Verfügbare Farbpaletten definieren
    const colorPalettes = {
        'default': {
            name: 'Standard',
            primary: '#7145e3',
            secondary: '#4e92f9',
            accent: '#daa520',
            background: '#1a1a2e',
            text: '#e0e0e0'
        },
        'dark-blue': {
            name: 'Dunkelblau',
            primary: '#3a86ff',
            secondary: '#8338ec',
            accent: '#ff006e',
            background: '#14213d',
            text: '#ffffff'
        },
        'monochrome': {
            name: 'Monochrom',
            primary: '#454545',
            secondary: '#707070',
            accent: '#f5f5f5',
            background: '#242424',
            text: '#e0e0e0'
        },
        'earth-tone': {
            name: 'Erdtöne',
            primary: '#99582a',
            secondary: '#bb9457',
            accent: '#ffe6a7',
            background: '#432818',
            text: '#ffe6a7'
        },
        'vibrant': {
            name: 'Lebendig',
            primary: '#ff0054',
            secondary: '#ff5400',
            accent: '#ffbd00',
            background: '#240046',
            text: '#ffffff'
        }
    };

    // Palette-Switcher erstellen
    function createPaletteSwitcher() {
        const paletteContainer = document.getElementById('palette-switcher');
        if (!paletteContainer) return;

        // Palette-Auswahl HTML erstellen
        paletteContainer.innerHTML = `
            <h5 class="mb-3">Farbpaletten</h5>
            <div class="d-flex flex-wrap gap-2 mb-4">
                ${Object.keys(colorPalettes).map(key => `
                    <div class="palette-item${key === 'default' ? ' active' : ''}" data-palette="${key}">
                        <div class="palette-preview">
                            <span style="background-color: ${colorPalettes[key].primary}"></span>
                            <span style="background-color: ${colorPalettes[key].secondary}"></span>
                            <span style="background-color: ${colorPalettes[key].accent}"></span>
                        </div>
                        <div class="palette-name">${colorPalettes[key].name}</div>
                    </div>
                `).join('')}
            </div>
        `;

        // Event-Listener für Farbpaletten hinzufügen
        document.querySelectorAll('.palette-item').forEach(item => {
            item.addEventListener('click', function() {
                // Aktive Klasse entfernen
                document.querySelectorAll('.palette-item').forEach(i => i.classList.remove('active'));
                
                // Neue aktive Palette festlegen
                this.classList.add('active');
                
                // Palette anwenden
                applyPalette(this.getAttribute('data-palette'));
            });
        });
    }

    // Farbpalette auf Template anwenden
    function applyPalette(paletteKey) {
        const palette = colorPalettes[paletteKey];
        if (!palette) return;

        // Template-Vorschau auswählen
        const templatePreview = document.querySelector('.template-preview-container');
        if (!templatePreview) return;

        // CSS-Variablen im Root für Live-Vorschau setzen
        document.documentElement.style.setProperty('--preview-primary', palette.primary);
        document.documentElement.style.setProperty('--preview-secondary', palette.secondary);
        document.documentElement.style.setProperty('--preview-accent', palette.accent);
        document.documentElement.style.setProperty('--preview-background', palette.background);
        document.documentElement.style.setProperty('--preview-text', palette.text);

        // Klasse zum Body hinzufügen, um zu zeigen, dass eine benutzerdefinierte Palette aktiv ist
        document.body.setAttribute('data-palette', paletteKey);

        // Ereignis auslösen, dass eine Palette angewendet wurde
        const event = new CustomEvent('paletteApplied', { detail: { palette: paletteKey }});
        document.dispatchEvent(event);
    }

    // Initialisierung
    createPaletteSwitcher();
});