/**
 * Contact form submission handler
 */
document.addEventListener('DOMContentLoaded', function() {
    // Get the contact form element
    const contactForm = document.getElementById('contactForm');
    
    // Initialize the file upload field
    const fileUpload = document.getElementById('fileUpload');
    if (fileUpload) {
        fileUpload.addEventListener('change', function() {
            const fileList = this.files;
            let fileNames = '';
            if (fileList.length > 0) {
                for (let i = 0; i < fileList.length; i++) {
                    fileNames += fileList[i].name + (i < fileList.length - 1 ? ', ' : '');
                }
                const fileText = document.querySelector('.form-text');
                if (fileText) {
                    fileText.textContent = `Selected files: ${fileNames}`;
                }
            }
        });
    }
    
    // Initialize the privacy policy checkbox
    const privacyCheckbox = document.getElementById('privacyPolicy');
    if (privacyCheckbox) {
        privacyCheckbox.addEventListener('change', function() {
            // Toggle the checked state visually if needed
        });
    }
    
    if (contactForm) {
        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            const privacyChecked = document.getElementById('privacyPolicy').checked;
            const files = document.getElementById('fileUpload').files;
            
            // Basic validation
            if (!name || !email || !subject || !message) {
                showFormMessage('Please fill in all fields', 'danger');
                return;
            }
            
            if (!privacyChecked) {
                showFormMessage('Please agree to the privacy policy', 'danger');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showFormMessage('Please enter a valid email address', 'danger');
                return;
            }
            
            try {
                // Show loading state
                const submitButton = contactForm.querySelector('button[type="submit"]');
                const originalButtonText = submitButton.innerHTML;
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...';
                
                // Create FormData object for file uploads
                const formData = new FormData();
                formData.append('name', name);
                formData.append('email', email);
                formData.append('subject', subject);
                formData.append('message', message);
                
                // Add files to FormData
                for (let i = 0; i < files.length; i++) {
                    formData.append('files', files[i]);
                }
                
                // Get CSRF token for secure requests
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
                
                // Send data to the server
                const response = await fetch('/api/contact', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        // Include CSRF token if available
                        ...(csrfToken && { 'X-CSRFToken': csrfToken })
                    }
                });
                
                const data = await response.json();
                
                // Reset button state
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
                
                if (response.ok) {
                    // Show success message
                    showFormMessage(data.message, 'success');
                    // Reset form
                    contactForm.reset();
                    // Reset file upload text
                    const fileText = document.querySelector('.form-text');
                    if (fileText) {
                        fileText.textContent = 'Upload images, logos, videos, and other files for your website project.';
                    }
                } else {
                    // Show error message
                    showFormMessage(data.message || 'Something went wrong. Please try again.', 'danger');
                }
            } catch (error) {
                console.error('Error:', error);
                showFormMessage('An error occurred while sending your message. Please try again later.', 'danger');
                
                // Reset button state
                const submitButton = contactForm.querySelector('button[type="submit"]');
                submitButton.disabled = false;
                submitButton.innerHTML = 'Send Message';
            }
        });
    }
    
    // Function to show form messages
    function showFormMessage(message, type) {
        const formStatus = document.getElementById('form-status');
        if (formStatus) {
            formStatus.className = `alert alert-${type} d-block`;
            formStatus.textContent = message;
            
            // Automatically hide the message after 5 seconds
            setTimeout(() => {
                formStatus.className = 'alert d-none';
            }, 5000);
        }
    }
});