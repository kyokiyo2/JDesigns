/**
 * Script to swap price elements with preview buttons in template cards
 */
document.addEventListener('DOMContentLoaded', function() {
    // Find all template price elements
    const templatePrices = document.querySelectorAll('.template-price');
    
    // Loop through each price element
    templatePrices.forEach((priceElement, index) => {
        // Get the parent template card
        const templateCard = priceElement.closest('.template-card');
        if (!templateCard) return;
        
        // Get template category and title to build a URL
        const templateCategory = templateCard.closest('[data-category]')?.getAttribute('data-category') || 'generic';
        const templateTitle = templateCard.querySelector('.template-title')?.textContent.trim().toLowerCase().replace(/\s+/g, '_') || 'template';
        
        // Find the parent div that contains buttons and the price
        const actionDiv = priceElement.closest('.d-flex');
        if (!actionDiv) return;
        
        // Find existing Get Started button
        const getStartedButton = actionDiv.querySelector('a.btn-outline-primary');
        if (!getStartedButton) return;
        
        // Keep the original Get Started button
        
        // Create a preview button
        const previewButton = document.createElement('a');
        previewButton.href = `/templates/${templateCategory}_${templateTitle}_template`.replace(/_+/g, '_');
        previewButton.className = 'btn btn-primary template-preview-btn';
        previewButton.setAttribute('data-template-type', templateCategory);
        previewButton.textContent = 'Preview';
        
        // Remove the price element
        priceElement.remove();
        
        // Fix the container styles
        actionDiv.style.display = 'flex';
        actionDiv.style.justifyContent = 'flex-end';
        actionDiv.style.alignItems = 'center';
        actionDiv.style.gap = '8px';
        
        // Insert preview button before the Get Started button
        actionDiv.insertBefore(previewButton, getStartedButton);
    });
    
    // Initialize page transitions for the new buttons
    if (typeof setupTemplateTransitions === 'function') {
        setupTemplateTransitions();
    }
});