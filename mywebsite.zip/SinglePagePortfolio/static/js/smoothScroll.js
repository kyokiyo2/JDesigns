/**
 * Smooth scrolling functionality for navigation links
 */
document.addEventListener('DOMContentLoaded', function() {
    // Select all links with hash (#) in href attribute
    const scrollLinks = document.querySelectorAll('a[href^="#"]');
    
    // Add click event listener to each link
    scrollLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Prevent default anchor click behavior
            e.preventDefault();
            
            // Get the target element using the hash from the clicked link
            const targetId = this.getAttribute('href');
            
            // Skip if the target is just "#" (no specific target)
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            
            // If the target element exists
            if (targetElement) {
                // Calculate the distance to scroll
                const navbarHeight = document.querySelector('#mainNav').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navbarHeight;
                
                // Smooth scroll to the target
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // If on mobile, close the navbar collapse after clicking a link
                const navbarToggler = document.querySelector('.navbar-toggler');
                const navbarCollapse = document.querySelector('.navbar-collapse');
                
                if (window.getComputedStyle(navbarToggler).display !== 'none' && navbarCollapse.classList.contains('show')) {
                    navbarToggler.click();
                }
            }
        });
    });
    
    // Add scroll event listener for navbar styling
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('#mainNav');
        
        if (window.scrollY > 100) {
            navbar.classList.add('navbar-shrink');
        } else {
            navbar.classList.remove('navbar-shrink');
        }
    });
});
