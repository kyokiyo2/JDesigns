/**
 * Page Transition Animations
 * 
 * Provides smooth transition effects when navigating between template views
 */

document.addEventListener('DOMContentLoaded', function() {
    // Create transition overlay element if it doesn't exist
    if (!document.querySelector('.transition-overlay')) {
        const transitionOverlay = document.createElement('div');
        transitionOverlay.classList.add('transition-overlay');
        document.body.appendChild(transitionOverlay);
        
        // Add a centered loader within the overlay for visual feedback
        const loader = document.createElement('div');
        loader.classList.add('transition-loader');
        transitionOverlay.appendChild(loader);
    }

    // Set up click handlers for all template preview links
    setupTemplateTransitions();
    
    // Handle browser back/forward navigation
    window.addEventListener('popstate', handlePopState);
    
    // Add animation classes to elements with delay for entrance animation
    setTimeout(() => {
        animatePageElements();
    }, 300);
});

/**
 * Set up transition handlers for template preview links
 */
function setupTemplateTransitions() {
    // Find all template preview links
    const previewLinks = document.querySelectorAll('.template-preview-btn');
    
    previewLinks.forEach(link => {
        // Only apply to links that lead to another page (not modal toggles)
        if (link.getAttribute('href') && link.getAttribute('href') !== '#' && !link.hasAttribute('data-bs-toggle')) {
            link.addEventListener('click', handleTemplateClick);
        }
    });
    
    // Also handle "back to templates" links
    const backLinks = document.querySelectorAll('a[href="/templates"]');
    backLinks.forEach(link => {
        link.addEventListener('click', handleBackClick);
    });
}

/**
 * Handle template preview link clicks
 * @param {Event} e - Click event
 */
function handleTemplateClick(e) {
    e.preventDefault();
    const targetUrl = this.getAttribute('href');
    const templateType = this.getAttribute('data-template');
    
    // Store current scroll position for when user returns
    sessionStorage.setItem('lastScrollPosition', window.scrollY);
    
    // Show the template loader animation if available
    if (typeof showTemplateLoader === 'function') {
        showTemplateLoader(templateType || 'default');
    } else {
        // Fallback to basic transition if animation function not loaded
        const transitionOverlay = document.querySelector('.transition-overlay');
        transitionOverlay.classList.add('slide-in');
    }
    
    // Wait for animation to complete before loading new page
    setTimeout(() => {
        // Update URL and load new content
        window.history.pushState({ type: 'template', url: targetUrl }, '', targetUrl);
        fetchAndUpdateContent(targetUrl);
    }, 2000); // Longer duration to enjoy the animation
}

/**
 * Handle "back to templates" link clicks
 * @param {Event} e - Click event
 */
function handleBackClick(e) {
    e.preventDefault();
    const targetUrl = '/templates';
    
    // Animate transition overlay
    const transitionOverlay = document.querySelector('.transition-overlay');
    transitionOverlay.classList.add('slide-in');
    
    // Wait for animation to complete before loading new page
    setTimeout(() => {
        // Update URL and load new content
        window.history.pushState({ type: 'templates', url: targetUrl }, '', targetUrl);
        fetchAndUpdateContent(targetUrl);
    }, 600); // Match this with CSS transition duration
}

/**
 * Handle browser back/forward navigation
 * @param {Event} e - PopState event
 */
function handlePopState(e) {
    // Get current URL from location
    const currentUrl = window.location.pathname;
    
    // Animate transition overlay
    const transitionOverlay = document.querySelector('.transition-overlay');
    transitionOverlay.classList.add('slide-in');
    
    // Wait for animation to complete before loading page content
    setTimeout(() => {
        fetchAndUpdateContent(currentUrl);
    }, 600); // Match this with CSS transition duration
}

/**
 * Fetch and update page content
 * @param {string} url - URL to fetch
 */
function fetchAndUpdateContent(url) {
    fetch(url)
        .then(response => response.text())
        .then(html => {
            // Extract content from fetched HTML
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const content = doc.querySelector('main');
            
            // Update page title
            document.title = doc.title;
            
            // Update page content
            document.querySelector('main').innerHTML = content.innerHTML;
            
            // Reset transition overlay
            const transitionOverlay = document.querySelector('.transition-overlay');
            transitionOverlay.classList.remove('slide-in');
            
            // Scroll to top for template pages, or restore position for templates list
            if (url === '/templates' && sessionStorage.getItem('lastScrollPosition')) {
                window.scrollTo(0, parseInt(sessionStorage.getItem('lastScrollPosition')));
            } else {
                window.scrollTo(0, 0);
            }
            
            // Reinitialize components on the new page
            reinitializeComponents();
        })
        .catch(error => {
            console.error('Error during page transition:', error);
            // On error, just navigate normally
            window.location.href = url;
        });
}

/**
 * Reinitialize components after content update
 */
function reinitializeComponents() {
    // Reinitialize template transitions
    setupTemplateTransitions();
    
    // Reinitialize template category filters if on templates page
    if (window.location.pathname === '/templates' && typeof initTemplateCategoryFilters === 'function') {
        initTemplateCategoryFilters();
    }
    
    // Reinitialize tooltips
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        [...tooltipTriggerList].map(el => new bootstrap.Tooltip(el));
    }
    
    // Animate elements
    animatePageElements();
}

/**
 * Animate page elements after transition
 */
function animatePageElements() {
    // Find elements to animate
    const elementsToAnimate = document.querySelectorAll('.fade-in-element, .slide-up-element');
    
    // Add animation classes with slight delay for each element
    elementsToAnimate.forEach((element, index) => {
        setTimeout(() => {
            if (element.classList.contains('fade-in-element')) {
                element.classList.add('fade-in');
            } else if (element.classList.contains('slide-up-element')) {
                element.classList.add('slide-up');
            }
        }, 100 + (index * 100)); // Stagger the animations
    });
}