/**
 * Enhanced template navigation with smooth scrolling and category filtering
 */
document.addEventListener('DOMContentLoaded', function() {
    // Template category filtering
    const categoryButtons = document.querySelectorAll('.template-category-btn');
    const templateItems = document.querySelectorAll('.template-item');
    
    if (categoryButtons.length > 0 && templateItems.length > 0) {
        categoryButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                categoryButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const category = this.getAttribute('data-category');
                
                // Add animation for filtering
                templateItems.forEach(item => {
                    item.style.opacity = '0';
                    item.style.transform = 'translateY(20px)';
                });
                
                // Delay to allow fade out animation
                setTimeout(() => {
                    // Show/hide templates based on category
                    templateItems.forEach(item => {
                        if (category === 'all' || item.getAttribute('data-category') === category) {
                            item.style.display = 'block';
                            // Stagger the fade-in animation for visible items
                            setTimeout(() => {
                                item.style.opacity = '1';
                                item.style.transform = 'translateY(0)';
                            }, Math.random() * 200); // Random delay for natural effect
                        } else {
                            item.style.display = 'none';
                        }
                    });
                }, 300);
            });
        });
    }
    
    // Smooth scrolling for template section navigation
    const templateNavLinks = document.querySelectorAll('.template-nav-link');
    
    if (templateNavLinks.length > 0) {
        templateNavLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId.startsWith('#')) {
                    const targetElement = document.querySelector(targetId);
                    
                    if (targetElement) {
                        const navbarHeight = document.querySelector('#mainNav').offsetHeight;
                        const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navbarHeight - 20; // Extra 20px for spacing
                        
                        window.scrollTo({
                            top: targetPosition,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    }
    
    // Add transition styles for template items
    templateItems.forEach(item => {
        item.style.transition = 'opacity 0.4s ease, transform 0.4s ease, display 0.4s ease';
    });
    
    // Back to top button specifically for templates page
    const backToTopBtn = document.querySelector('.template-back-to-top');
    
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 500) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        
        backToTopBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
    
    // Animated entrance for template cards on page load
    function animateTemplateCards() {
        const cards = document.querySelectorAll('.template-card');
        cards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('animate__animated', 'animate__fadeInUp');
            }, 100 * index); // Stagger animation
        });
    }
    
    // Run animation after a short delay to ensure everything is loaded
    setTimeout(animateTemplateCards, 300);
});