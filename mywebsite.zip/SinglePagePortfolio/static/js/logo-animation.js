/**
 * Enhanced logo interactivity
 */
document.addEventListener('DOMContentLoaded', function() {
    const logo = document.querySelector('.logo-img');
    
    if (logo) {
        // Add 3D tilt effect on mousemove
        logo.addEventListener('mousemove', function(e) {
            const logoRect = this.getBoundingClientRect();
            const x = e.clientX - logoRect.left;
            const y = e.clientY - logoRect.top;
            
            // Calculate rotation based on mouse position
            const xRotation = (y / logoRect.height - 0.5) * 20; // -10 to 10 degrees
            const yRotation = (0.5 - x / logoRect.width) * 20; // -10 to 10 degrees
            
            // Apply the rotation transform
            this.style.transform = `perspective(1000px) rotateX(${xRotation}deg) rotateY(${yRotation}deg) scale(1.1)`;
        });
        
        // Reset transform on mouseout
        logo.addEventListener('mouseout', function() {
            this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
        });
        
        // Add click effect
        logo.addEventListener('click', function() {
            // Add a temporary class for animation
            this.classList.add('logo-pulse');
            
            // Remove the class after animation completes
            setTimeout(() => {
                this.classList.remove('logo-pulse');
            }, 500);
        });
    }
});