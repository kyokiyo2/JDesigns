/**
 * Language Toggle Functionality
 * Implements smooth animations for language switching with flag indicators
 */

// Languages supported by the application
const SUPPORTED_LANGUAGES = ['en', 'de'];
// Default language
const DEFAULT_LANGUAGE = 'en';
// Store the current language
let currentLanguage = localStorage.getItem('language') || DEFAULT_LANGUAGE;

/**
 * Initialize the language toggle functionality
 */
function initLanguageToggle() {
    // Add click event listeners to language flags
    document.querySelectorAll('.language-flag').forEach(flag => {
        flag.addEventListener('click', function() {
            const language = this.getAttribute('data-lang');
            applyLanguage(language);
            animateFlag(this);
        });
    });
    
    // Add click event listeners to language dropdown items
    document.querySelectorAll('.dropdown-menu .dropdown-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const language = this.getAttribute('data-language');
            applyLanguage(language);
            
            // Update active state in dropdown
            document.querySelectorAll('.dropdown-menu .dropdown-item').forEach(menuItem => {
                menuItem.classList.remove('active');
            });
            this.classList.add('active');
            
            // Optional: Update the dropdown button text
            const dropdownButton = document.querySelector('#languageDropdown');
            if (dropdownButton) {
                dropdownButton.innerHTML = `<i class="fas fa-globe me-1"></i> ${language === 'en' ? 'English' : 'Deutsch'}`;
            }
        });
    });

    // Apply the saved language on page load
    applyCurrentLanguage();
}

/**
 * Apply the currently selected language
 */
function applyCurrentLanguage() {
    // Mark the current language flag as active (for flag-based selectors)
    document.querySelectorAll('.language-flag').forEach(flag => {
        if (flag.getAttribute('data-lang') === currentLanguage) {
            flag.classList.add('active');
        } else {
            flag.classList.remove('active');
        }
    });
    
    // Mark the current language dropdown item as active (for dropdown selectors)
    document.querySelectorAll('.dropdown-menu .dropdown-item').forEach(item => {
        if (item.getAttribute('data-language') === currentLanguage) {
            item.classList.add('active');
            
            // Update dropdown button text
            const dropdownButton = document.querySelector('#languageDropdown');
            if (dropdownButton) {
                dropdownButton.innerHTML = `<i class="fas fa-globe me-1"></i> ${currentLanguage === 'en' ? 'English' : 'Deutsch'}`;
            }
        } else {
            item.classList.remove('active');
        }
    });

    // Apply the language to the page content
    applyLanguage(currentLanguage, false); // Don't save again, just apply
}

/**
 * Apply selected language to page content
 * @param {string} lang - Selected language code (en/de)
 * @param {boolean} save - Whether to save the language preference
 */
function applyLanguage(lang, save = true) {
    if (SUPPORTED_LANGUAGES.includes(lang)) {
        if (save) {
            // Save language preference
            localStorage.setItem('language', lang);
            currentLanguage = lang;
            
            // Send language preference to server
            try {
                fetch('/set_language', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ language: lang }),
                }).catch(error => console.log('Error setting language on server:', error));
            } catch (e) {
                console.log('Error saving language preference:', e);
            }
        }

        // Update active flag indicator (for flag-based selectors)
        document.querySelectorAll('.language-flag').forEach(flag => {
            if (flag.getAttribute('data-lang') === lang) {
                flag.classList.add('active');
            } else {
                flag.classList.remove('active');
            }
        });
        
        // Update active dropdown item (for dropdown selectors)
        document.querySelectorAll('.dropdown-menu .dropdown-item').forEach(item => {
            if (item.getAttribute('data-language') === lang) {
                item.classList.add('active');
                
                // Update dropdown button text
                const dropdownButton = document.querySelector('#languageDropdown');
                if (dropdownButton) {
                    dropdownButton.innerHTML = `<i class="fas fa-globe me-1"></i> ${lang === 'en' ? 'English' : 'Deutsch'}`;
                }
            } else {
                item.classList.remove('active');
            }
        });

        // Apply translations to all elements with data-lang-* attributes
        document.querySelectorAll('[data-lang-' + lang + ']').forEach(element => {
            element.textContent = element.getAttribute('data-lang-' + lang);
        });
    }
}

/**
 * Animate flag when selected
 * @param {HTMLElement} flagElement - The flag element to animate
 */
function animateFlag(flagElement) {
    // Remove any existing animations
    flagElement.classList.remove('animate-flag');
    
    // Trigger reflow to restart animation
    void flagElement.offsetWidth;
    
    // Add animation class
    flagElement.classList.add('animate-flag');
    
    // Optionally add some haptic feedback for mobile
    if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
    }
}

// Initialize language toggle when DOM is loaded
document.addEventListener('DOMContentLoaded', initLanguageToggle);