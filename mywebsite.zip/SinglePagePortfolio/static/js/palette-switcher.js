/**
 * Farbpaletten-Vorschau Tool
 */

// Farbpaletten definieren
const palettes = {
    'default': {
        primary: '#7145e3',
        secondary: '#4e92f9',
        accent: '#daa520',
        background: '#1a1a2e',
        text: '#e0e0e0'
    },
    'darkBlue': {
        primary: '#3a86ff',
        secondary: '#8338ec',
        accent: '#ff006e',
        background: '#14213d',
        text: '#ffffff'
    },
    'monochrome': {
        primary: '#454545',
        secondary: '#707070',
        accent: '#f5f5f5',
        background: '#242424',
        text: '#e0e0e0'
    },
    'earthTone': {
        primary: '#99582a',
        secondary: '#bb9457',
        accent: '#ffe6a7',
        background: '#432818',
        text: '#ffe6a7'
    },
    'vibrant': {
        primary: '#ff0054',
        secondary: '#ff5400',
        accent: '#ffbd00',
        background: '#240046',
        text: '#ffffff'
    }
};

// Farbpalette anwenden
function applyPalette(paletteKey) {
    const palette = palettes[paletteKey];
    if (!palette) return;
    
    // Alle Palette-Items deaktivieren
    document.querySelectorAll('.palette-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Aktuell ausgewählte Palette aktivieren
    document.querySelector(`.palette-item[onclick="applyPalette('${paletteKey}')"]`).classList.add('active');
    
    const previewContainer = document.getElementById('preview-container');
    if (!previewContainer) return;
    
    // CSS-Variablen im Container aktualisieren
    previewContainer.style.setProperty('--preview-primary', palette.primary);
    previewContainer.style.setProperty('--preview-secondary', palette.secondary);
    previewContainer.style.setProperty('--preview-accent', palette.accent);
    previewContainer.style.setProperty('--preview-background', palette.background);
    previewContainer.style.setProperty('--preview-text', palette.text);
    
    // Vorschau-Header anpassen
    const header = previewContainer.querySelector('.template-preview-header');
    if (header) {
        header.style.backgroundColor = palette.primary;
        header.style.color = palette.text;
    }
    
    // Vorschau-Navigation anpassen
    const nav = previewContainer.querySelector('.template-preview-nav');
    if (nav) {
        nav.style.backgroundColor = palette.background;
        
        const navLinks = nav.querySelectorAll('a');
        navLinks.forEach(link => {
            link.style.color = palette.text;
        });
        
        const activeLink = nav.querySelector('a.active');
        if (activeLink) {
            activeLink.style.color = palette.accent;
        }
    }
    
    // Vorschau-Content anpassen
    const content = previewContainer.querySelector('.template-preview-content');
    if (content) {
        content.style.backgroundColor = palette.background;
        content.style.color = palette.text;
        
        // Primary Buttons anpassen
        const primaryButtons = content.querySelectorAll('.template-preview-button-primary');
        primaryButtons.forEach(button => {
            button.style.backgroundColor = palette.primary;
            button.style.color = '#fff';
        });
        
        // Accent Buttons anpassen
        const accentButtons = content.querySelectorAll('.template-preview-button-accent');
        accentButtons.forEach(button => {
            button.style.backgroundColor = palette.accent;
            button.style.color = '#fff';
        });
        
        // Cards anpassen
        const cards = content.querySelectorAll('.card');
        cards.forEach(card => {
            card.style.backgroundColor = shadeColor(palette.background, 20);
            card.style.borderColor = shadeColor(palette.background, 40);
        });
    }
}

// Hilfsfunktion zum Aufhellen/Abdunkeln von Farben
function shadeColor(color, percent) {
    let R = parseInt(color.substring(1, 3), 16);
    let G = parseInt(color.substring(3, 5), 16);
    let B = parseInt(color.substring(5, 7), 16);

    R = parseInt(R * (100 + percent) / 100);
    G = parseInt(G * (100 + percent) / 100);
    B = parseInt(B * (100 + percent) / 100);

    R = (R < 255) ? R : 255;
    G = (G < 255) ? G : 255;
    B = (B < 255) ? B : 255;

    const RR = ((R.toString(16).length == 1) ? "0" + R.toString(16) : R.toString(16));
    const GG = ((G.toString(16).length == 1) ? "0" + G.toString(16) : G.toString(16));
    const BB = ((B.toString(16).length == 1) ? "0" + B.toString(16) : B.toString(16));

    return "#" + RR + GG + BB;
}

// Initialisierung beim Laden der Seite
document.addEventListener('DOMContentLoaded', function() {
    // Standard-Palette anwenden
    applyPalette('default');
    
    // Palette-Items Styling
    const paletteItems = document.querySelectorAll('.palette-item');
    paletteItems.forEach(item => {
        item.style.padding = '10px';
        item.style.borderRadius = '8px';
        item.style.backgroundColor = 'rgba(0, 0, 0, 0.2)';
        item.style.cursor = 'pointer';
        item.style.transition = 'all 0.3s ease';
        item.style.minWidth = '90px';
        item.style.textAlign = 'center';
        
        // Hover-Effekt
        item.addEventListener('mouseenter', function() {
            if (!this.classList.contains('active')) {
                this.style.transform = 'translateY(-5px)';
                this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.2)';
            }
        });
        
        item.addEventListener('mouseleave', function() {
            if (!this.classList.contains('active')) {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            }
        });
    });
    
    // Palette Preview Spans Styling
    const previewSpans = document.querySelectorAll('.palette-preview span');
    previewSpans.forEach(span => {
        span.style.flex = '1';
        span.style.height = '20px';
        span.style.display = 'block';
    });
    
    // Palette Preview Container Styling
    const previewContainers = document.querySelectorAll('.palette-preview');
    previewContainers.forEach(container => {
        container.style.display = 'flex';
        container.style.width = '100%';
        container.style.height = '20px';
        container.style.borderRadius = '5px';
        container.style.overflow = 'hidden';
        container.style.marginBottom = '8px';
    });
});