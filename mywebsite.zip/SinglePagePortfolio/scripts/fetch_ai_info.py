import trafilatura
import requests
from bs4 import BeautifulSoup

def get_website_text_content(url):
    """Extract text content from a website using trafilatura."""
    try:
        downloaded = trafilatura.fetch_url(url)
        if downloaded:
            text = trafilatura.extract(downloaded)
            return text
        else:
            return "Couldn't download content from the URL"
    except Exception as e:
        return f"Error extracting text: {str(e)}"

# URLs to scrape
urls = [
    "https://botsonic.com/ai-agents",
    "https://beam.ai/solutions/customer-service"
]

# Collect information from websites
results = {}
for url in urls:
    results[url] = get_website_text_content(url)

# Print results for AI Agents information
for url, content in results.items():
    print(f"\n--- Content from {url} ---\n")
    print(content[:1000] + "...\n")  # Print first 1000 chars