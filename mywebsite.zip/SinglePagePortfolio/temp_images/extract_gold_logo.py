from PIL import Image
import numpy as np

# Open the gold logo image
img = Image.open('attached_assets/8888.png')
img = img.convert("RGBA")

# Get image data as numpy array
data = np.array(img)

# Create a mask where black pixels are (close to black)
# These are pixels where R, G, and B are all very low values
black_mask = (data[:,:,0] < 30) & (data[:,:,1] < 30) & (data[:,:,2] < 30)

# Set those black pixels to be completely transparent
data[black_mask, 3] = 0  # Set alpha channel to 0

# Create a new image from the modified data
result = Image.fromarray(data)

# Resize to desired dimensions
result = result.resize((200, 200))

# Save with transparency
result.save('static/images/gold-logo-extracted.png')

print("Created transparent gold logo!")