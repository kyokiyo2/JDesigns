from PIL import Image
import numpy as np

# Open the image
img = Image.open('attached_assets/better.png')
img = img.convert("RGBA")

# Create a transparent background
data = np.array(img)
r, g, b, a = data.T

# Create mask for white-ish pixels 
# (adjust the threshold values as needed)
white_areas = (r > 200) & (g > 200) & (b > 200)
data[..., :][white_areas.T] = (255, 255, 255, 0)  # Make white pixels transparent

# Save the result
transparent_img = Image.fromarray(data)
transparent_img = transparent_img.resize((300, 300))
transparent_img.save('static/images/jd-logo-transparent-bg.png')

print("Transparent background image created!")