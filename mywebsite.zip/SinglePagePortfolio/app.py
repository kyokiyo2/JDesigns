import os
import logging
import uuid
import requests
import re
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, session, send_from_directory
from database import db
from datetime import datetime
from flask_wtf.csrf import CSRFProtect

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
# Set secure secret key from environment variable without fallback
app.secret_key = os.environ.get("SESSION_SECRET") 
if not app.secret_key:
    app.logger.error("No SESSION_SECRET environment variable set!")
    app.secret_key = os.urandom(32)  # Generate a random key in development

# Initialize CSRF protection
csrf = CSRFProtect(app)

# Add a direct route to serve the new AI example image
@app.route('/direct-ai-example')
def direct_ai_example():
    return send_from_directory('static/images/ai', 'use-example-updated-1747762730.png')

# Function to detect if user is from Germany with rate limiting protection
def is_german_ip(ip_address):
    try:
        # For testing purposes, you can use this to simulate German IPs
        if ip_address == '127.0.0.1' and os.environ.get('SIMULATE_GERMAN_IP') == 'true':
            return True
            
        # Use a safer way to make the request
        # Add proper timeout and error handling
        response = requests.get(
            f'https://ipapi.co/{ip_address}/json/',
            timeout=5,
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        
        # Check for rate limiting or errors
        if response.status_code != 200:
            logging.warning(f"IP API returned status code {response.status_code}")
            # Default to English on API failure
            return False
            
        data = response.json()
        return data.get('country_code') == 'DE'
    except Exception as e:
        logging.error(f"Error detecting country from IP: {str(e)}")
        # Default to English on error
        return False

# Configure file uploads
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'doc', 'docx', 'txt'}

# Configure the database
database_url = os.environ.get("DATABASE_URL")
if database_url and database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize SQLAlchemy with the app
db.init_app(app)

@app.route("/set_language", methods=["POST"])
def set_language():
    """Endpoint to set the language preference in the session"""
    try:
        data = request.get_json()
        language = data.get('language')
        
        if language in ['en', 'de']:
            session['language'] = language
            return jsonify({'success': True}), 200
        else:
            return jsonify({'success': False, 'message': 'Invalid language'}), 400
    except Exception as e:
        logging.error(f"Error setting language: {str(e)}")
        return jsonify({'success': False, 'message': 'An error occurred'}), 500

@app.route("/")
def index():
    # Get user's IP address
    ip_address = request.remote_addr
    
    # Check if user has language preference in session
    if 'language' not in session:
        # If not, and the user is from Germany, set language to German
        if is_german_ip(ip_address):
            session['language'] = 'de'
        else:
            session['language'] = 'en'
    
    # Log the language detection for debugging
    logging.debug(f"User IP: {ip_address}, Language: {session.get('language')}")
    
    return render_template("index.html", language=session.get('language', 'en'))
    
@app.route("/web-design")
def web_design():
    return render_template("web_design.html", language=session.get('language', 'en'))
    
@app.route("/templates")
def website_templates():
    return render_template("website_templates.html", language=session.get('language', 'en'))
    
@app.route("/templates/restaurant")
def restaurant_template():
    return render_template("website_templates/restaurant_template.html", language=session.get('language', 'en'))
    
@app.route("/templates/portfolio")
def portfolio_template():
    return render_template("website_templates/portfolio_template.html", language=session.get('language', 'en'))
    
@app.route("/templates/ecommerce")
def ecommerce_template():
    return render_template("website_templates/ecommerce_template.html", language=session.get('language', 'en'))
    
@app.route("/templates/business")
def business_template():
    return render_template("website_templates/business_template.html", language=session.get('language', 'en'))
    
@app.route("/templates/blog")
def blog_template():
    return render_template("website_templates/blog_template.html", language=session.get('language', 'en'))
    
@app.route("/templates/personal")
def personal_template():
    return render_template("website_templates/personal_template.html", language=session.get('language', 'en'))
    
@app.route("/ai-agents")
def ai_agents():
    # Get user's IP address
    ip_address = request.remote_addr
    
    # Log the language detection for debugging
    logging.debug(f"User IP: {ip_address}, Language: {session.get('language')}")
    
    # Check if the user is from Germany or has German language preference
    if session.get('language') == 'de' or is_german_ip(ip_address):
        session['language'] = 'de'
        return render_template("ai_agents.html", language='de')
    else:
        return render_template("ai_agents_en.html", language='en')
        
@app.route("/ai-demo")
def ai_agents_demo():
    """Temporärer Endpunkt für die AI Agents Seite mit dem neu positionierten Text"""
    html_content = """
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AI Agents Demo</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            body {
                font-family: 'Poppins', sans-serif;
                background-color: #111;
                color: #fff;
            }
            
            .hero-container {
                background-color: #20222A;
                border-radius: 10px;
                padding: 30px;
                margin-bottom: 30px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            }
            
            .hero-title {
                color: white;
                font-size: 2rem;
                margin-bottom: 20px;
            }
            
            .hero-title span {
                color: #7145e3;
            }
            
            .hero-text {
                color: rgba(255, 255, 255, 0.8);
                margin-bottom: 30px;
            }
            
            .key-features-banner {
                background-color: #20222A;
                border-top: 1px solid rgba(113, 69, 237, 0.3);
                border-bottom: 1px solid rgba(113, 69, 237, 0.3);
                padding: 25px 0;
                margin: 70px 0;
                text-align: center;
            }
            
            .key-features-text {
                font-size: 1.5rem;
                color: #ffffff;
                letter-spacing: 1px;
                text-shadow: 0 0 15px rgba(113, 69, 237, 0.6);
                font-weight: 300;
                margin: 0;
            }
            
            .orange-highlight {
                color: #ff6b00;
                font-weight: 600;
            }
            
            .purple-highlight {
                color: #7145e3;
                font-weight: 600;
            }
            
            .info-section {
                background-color: #20222A;
                border-radius: 10px;
                padding: 30px;
                margin-top: 30px;
            }
            
            .section-heading {
                font-size: 1.8rem;
                margin-bottom: 20px;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <div class="container mt-5">
            <!-- Hero Section -->
            <div class="hero-container">
                <h1 class="hero-title">AI Agents für <span>intelligenten</span> Kundenservice</h1>
                <p class="hero-text">Upgrade von regelbasierten Chatbots zu KI-Agenten, die denken und handeln können. Automatisieren Sie komplexe Aufgaben und bieten Sie einen erstklassigen Kundenservice rund um die Uhr.</p>
                <a href="#" class="btn btn-primary">Jetzt beraten lassen</a>
            </div>
            
            <!-- Der gesamte Abstand bis zur nächsten Sektion -->
            <div style="height: 200px; position: relative;">
                <!-- Key Features Banner - GENAU MITTIG zwischen Hero und What Are AI Agents? -->
                <div style="position: absolute; top: 50%; left: 0; right: 0; transform: translateY(-50%);" class="key-features-banner">
                    <p class="key-features-text">
                        <span class="orange-highlight">Next-generation</span> AI customer service, 
                        <span class="purple-highlight">intelligent</span>, 
                        <span class="orange-highlight">responsive</span>, 
                        <span class="purple-highlight">24/7 availability</span>
                    </p>
                </div>
            </div>
            
            <!-- What Are AI Agents Section -->
            <div class="info-section">
                <h2 class="section-heading">Was sind AI Agents?</h2>
                <p class="text-center">KI-Agenten sind fortschrittliche virtuelle Assistenten, die über traditionelle Chatbots hinausgehen.</p>
            </div>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    """
    return html_content
    
@app.route("/test")
def test_form():
    return render_template("test_form.html")
    
@app.route("/contact_form")
def contact_form():
    return render_template("simple_form.html", message=None)
    
@app.route("/basic")
def basic_test():
    return render_template("basic.html")
    
@app.route("/contact")
def simplified_contact():
    return render_template("simplified_contact.html")
    
@app.route("/simplified_submit", methods=["POST"])
def simplified_submit():
    try:
        from models import Contact
        
        # Get form data and sanitize inputs
        name = sanitize_input(request.form.get('name', ''))
        email = sanitize_input(request.form.get('email', ''))
        subject = sanitize_input(request.form.get('subject', ''))
        message = sanitize_input(request.form.get('message', ''))
        
        # Validate form data
        if not all([name, email, subject, message]):
            return render_template("index.html", 
                                  message="Please fill in all fields", 
                                  message_type="danger")
        
        # Email validation with regex
        email_regex = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        if not email_regex.match(email):
            return render_template("index.html", 
                                  message="Please enter a valid email address", 
                                  message_type="danger")
        
        # Create and save new contact
        new_contact = Contact()
        new_contact.name = name
        new_contact.email = email
        new_contact.subject = subject
        new_contact.message = message
        
        db.session.add(new_contact)
        db.session.commit()
        
        # Return success
        return render_template("index.html", 
                              message="Thank you! Your message has been sent successfully.", 
                              message_type="success")
        
    except Exception as e:
        logging.error(f"Error submitting contact form: {str(e)}")
        return render_template("index.html", 
                              message="An error occurred. Please try again later.", 
                              message_type="danger")
    
@app.route("/simple_submit", methods=["POST"])
def simple_submit():
    try:
        from models import Contact
        
        # Get form data and sanitize inputs
        name = sanitize_input(request.form.get('name', ''))
        email = sanitize_input(request.form.get('email', ''))
        subject = sanitize_input(request.form.get('subject', ''))
        message = sanitize_input(request.form.get('message', ''))
        
        # Validate form data
        if not all([name, email, subject, message]):
            return render_template("index.html", 
                                  message="Please fill in all fields", 
                                  message_type="danger")
        
        # Email validation with regex
        email_regex = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        if not email_regex.match(email):
            return render_template("index.html", 
                                  message="Please enter a valid email address", 
                                  message_type="danger")
        
        # Create and save new contact
        new_contact = Contact()
        new_contact.name = name
        new_contact.email = email
        new_contact.subject = subject
        new_contact.message = message
        
        db.session.add(new_contact)
        db.session.commit()
        
        # Return success
        return render_template("index.html", 
                              message="Thank you! Your message has been sent successfully.", 
                              message_type="success")
        
    except Exception as e:
        logging.error(f"Error submitting contact form: {str(e)}")
        return render_template("index.html", 
                              message="An error occurred. Please try again later.", 
                              message_type="danger")

@app.route("/admin")
def admin():
    try:
        # Check for admin authentication here (this is a basic implementation)
        # In a real application, you would use a proper authentication system
        if 'admin_authenticated' not in session or not session['admin_authenticated']:
            # Redirect to a login page instead of allowing direct access
            flash('You need to log in to access the admin area', 'danger')
            return redirect(url_for('index'))
            
        from models import Contact
        # Get all contacts from newest to oldest
        contacts = Contact.query.order_by(Contact.created_at.desc()).all()
        return render_template("admin.html", contacts=contacts)
    except Exception as e:
        logging.error(f"Error accessing admin page: {str(e)}")
        return "An error occurred while loading the admin page.", 500

@app.route("/download/<path:file_path>")
def download_file(file_path):
    try:
        # Security: Validate the file_path is within the uploads directory
        uploads_dir = os.path.abspath(app.config['UPLOAD_FOLDER'])
        requested_path = os.path.abspath(file_path)
        
        # Prevent path traversal attacks by ensuring the path is within uploads directory
        if not requested_path.startswith(uploads_dir):
            logging.warning(f"Attempted path traversal attack: {file_path}")
            return "Access denied", 403
            
        # Check if file exists
        if not os.path.exists(requested_path):
            return "File not found", 404
            
        return send_file(requested_path, as_attachment=True)
    except Exception as e:
        logging.error(f"Error downloading file: {str(e)}")
        return "Error accessing file", 404

def allowed_file(filename):
    # Security: Validate file extension (whitelist approach)
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Security: Add function to validate user input
def sanitize_input(text):
    """Sanitize user input to prevent XSS attacks"""
    if not text:
        return ""
    # Remove potentially dangerous characters
    text = re.sub(r'[<>"\']', '', text)
    return text

@app.route("/api/contact", methods=["POST"])
@csrf.exempt  # Exempt this route from CSRF protection for now (will add proper AJAX CSRF later)
def submit_contact():
    try:
        from models import Contact
        
        # Check if the form data is sent as multipart/form-data
        if request.content_type and 'multipart/form-data' in request.content_type:
            # Get form field values and sanitize them
            name = sanitize_input(request.form.get('name', ''))
            email = sanitize_input(request.form.get('email', ''))
            subject = sanitize_input(request.form.get('subject', ''))
            message = sanitize_input(request.form.get('message', ''))
            
            # Validate form data
            if not all([name, email, subject, message]):
                return jsonify({'success': False, 'message': 'Please fill in all fields'}), 400
            
            # Email validation with regex
            email_regex = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            if not email_regex.match(email):
                return jsonify({'success': False, 'message': 'Please enter a valid email address'}), 400
            
            # Handle file uploads
            uploaded_files = request.files.getlist('files')
            file_paths = []
            
            for file in uploaded_files:
                if file and file.filename and allowed_file(file.filename):
                    try:
                        # Generate a unique filename
                        filename = secure_filename(file.filename)
                        unique_filename = f"{str(uuid.uuid4())}_{filename}"
                        
                        # Make sure upload folder exists
                        uploads_dir = os.path.abspath(app.config['UPLOAD_FOLDER'])
                        os.makedirs(uploads_dir, exist_ok=True)
                        
                        # Save the file with proper path handling
                        file_path = os.path.join(uploads_dir, unique_filename)
                        file.save(file_path)
                        
                        # Verify file was saved successfully
                        if os.path.exists(file_path):
                            file_paths.append(file_path)
                        else:
                            logging.error(f"Failed to save file: {filename}")
                    except Exception as file_error:
                        logging.error(f"Error saving file {file.filename}: {str(file_error)}")
            
            # Create and save new contact
            new_contact = Contact()
            new_contact.name = name
            new_contact.email = email
            new_contact.subject = subject
            new_contact.message = message
            new_contact.file_paths = ','.join(file_paths) if file_paths else None
            
            db.session.add(new_contact)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Thank you! Your message has been sent successfully.'}), 200
        
        # For backward compatibility with JSON requests
        else:
            data = request.get_json()
            if not data:
                return jsonify({'success': False, 'message': 'No data provided'}), 400
                
            # Get and sanitize input
            name = sanitize_input(data.get('name', ''))
            email = sanitize_input(data.get('email', ''))
            subject = sanitize_input(data.get('subject', ''))
            message = sanitize_input(data.get('message', ''))
            
            # Validate form data
            if not all([name, email, subject, message]):
                return jsonify({'success': False, 'message': 'Please fill in all fields'}), 400
            
            # Email validation with regex
            email_regex = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            if not email_regex.match(email):
                return jsonify({'success': False, 'message': 'Please enter a valid email address'}), 400
                
            # Create and save new contact
            new_contact = Contact()
            new_contact.name = name
            new_contact.email = email
            new_contact.subject = subject
            new_contact.message = message
            
            db.session.add(new_contact)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Thank you! Your message has been sent successfully.'}), 200
        
    except Exception as e:
        logging.error(f"Error submitting contact form: {str(e)}")
        return jsonify({'success': False, 'message': 'An error occurred. Please try again later.'}), 500

@app.route("/api/subscribe", methods=["POST"])
@csrf.exempt  # Exempt this endpoint from CSRF protection for AJAX requests
def subscribe():
    try:
        from models import Subscriber
        
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
            
        email = sanitize_input(data.get('email', ''))
        
        # Validate email
        if not email:
            return jsonify({'success': False, 'message': 'Please enter your email address'}), 400
            
        # Email validation with regex
        email_regex = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        if not email_regex.match(email):
            return jsonify({'success': False, 'message': 'Please enter a valid email address'}), 400
            
        # Check if email already exists
        existing_subscriber = Subscriber.query.filter_by(email=email).first()
        if existing_subscriber:
            return jsonify({'success': False, 'message': 'You are already subscribed!'}), 400
            
        # Create and save new subscriber
        new_subscriber = Subscriber()
        new_subscriber.email = email
        
        db.session.add(new_subscriber)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Thank you for subscribing!'}), 200
        
    except Exception as e:
        logging.error(f"Error subscribing: {str(e)}")
        return jsonify({'success': False, 'message': 'An error occurred. Please try again later.'}), 500

# Create database tables
with app.app_context():
    import models
    db.create_all()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
